#!/bin/sh
set -eu
mkdir -p backups
docker compose -f docker-compose.yml exec -T db pg_dump -U elite_user elite_kurye | gzip > backups/elite_$(date +%Y%m%d_%H%M).sql.gz
find backups -type f -mtime +14 -delete

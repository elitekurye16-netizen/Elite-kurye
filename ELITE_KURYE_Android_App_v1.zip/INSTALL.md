# ELİTE KURYE v4 KURULUM

## Sunucu
Ubuntu 22.04/24.04, Docker ve Docker Compose.

## 1. Paket
unzip ELITE_KURYE_Production_v4.zip
cd elite_kurye_production_v4

## 2. Gizli bilgiler
deploy/docker-compose.yml içindeki:
- CHANGE_ME_DB_PASSWORD
- CHANGE_ME_LONG_RANDOM_SECRET
değerlerini değiştir.

WEB_ORIGIN ve domainleri gerçek domaininle değiştir.

## 3. Başlat
docker compose -f deploy/docker-compose.yml up -d --build

## 4. Veritabanı
Şema ilk açılışta PostgreSQL'e uygulanmalıdır. Mevcut compose yapısında api container'ının DB hazır olduktan sonra `node migrate.js` çalıştırması önerilir; ilk kurulumda:
docker compose -f deploy/docker-compose.yml exec api node migrate.js

## 5. HTTPS
Nginx/Cloudflare üzerinden HTTPS kullan. Mobil uygulamada sadece HTTPS API kullan.

## 6. Mobil
cd courier-app
npm install
App.js içindeki API adresini gerçek API domainine ayarla.
npx expo start
Production Android:
npx eas build -p android
Production iOS:
npx eas build -p ios

## Örnek giriş
Admin: 05000000000 / Elite123!
Restaurant: 05000000001 / Restaurant123!
Courier: 05000000002 / Courier123!

İlk girişten sonra şifreleri değiştir.

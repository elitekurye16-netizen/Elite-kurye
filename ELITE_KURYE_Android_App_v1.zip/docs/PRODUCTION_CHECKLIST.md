# Production Checklist

- [ ] Gerçek domain
- [ ] HTTPS
- [ ] Güçlü DB password
- [ ] Güçlü JWT secret
- [ ] Örnek kullanıcı şifreleri değiştirildi
- [ ] DB portu dışarı kapalı
- [ ] Günlük backup cron
- [ ] Firebase/APNs push
- [ ] Background GPS izinleri
- [ ] Harita API anahtarı ve limitler
- [ ] S3/R2 teslim fotoğraf depolama
- [ ] Teslim kodu doğrulama
- [ ] KVKK ve saklama politikası
- [ ] Hata/log izleme
- [ ] Staging ortamında test
- [ ] Android AAB / iOS archive

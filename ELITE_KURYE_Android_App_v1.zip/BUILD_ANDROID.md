# ELİTE KURYE — GERÇEK ANDROID UYGULAMASI

## APK oluşturma
Gereksinimler:
- Node.js 20+
- Expo hesabı
- EAS CLI

```bash
cd courier-app
npm install
npx eas login
npx eas build:configure
```

Test APK:
```bash
npm run build:apk
```

Bu işlem EAS üzerinde Android APK üretir.

Google Play için:
```bash
npm run build:aab
```

Üretilen `.aab` dosyası Google Play Console'a yüklenir.

## API adresi
Build öncesi:
```bash
export EXPO_PUBLIC_API_URL=https://api.SIZINDOMAININIZ.com
```
veya EAS secrets/environment kullan.

## Önemli
APK'nın gerçek siparişlerle çalışması için önce API + PostgreSQL sunucusunun internette HTTPS üzerinden çalışıyor olması gerekir.

## Kurye uygulaması
- Giriş
- Sipariş listesi
- Paket durumları
- GPS
- Navigasyon
- Hakediş
- Teslimat akışı

Background GPS ve push bildirimleri için EAS production build kullanılmalıdır.

# ELİTE KURYE v4
Bursa/Gemlik motosikletli kurye operasyonu için yönetici + restoran + kurye altyapısı.

İş modeli:
- Kendi motoru: 65 TL/paket
- Şirket motoru: 55 TL/paket
- Restoran ücreti: mesafe tarifesine göre değişken
- Çoklu paket: ücret paket sayısı ile çarpılır
- Brüt: restoran geliri - kurye hakedişi
- Net: brüt - işletme giderleri

Kurulum: INSTALL.md
Production kontrolü: docs/PRODUCTION_CHECKLIST.md
Mobil: courier-app/README.md
